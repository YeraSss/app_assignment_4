package com.mycompany.groupproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
